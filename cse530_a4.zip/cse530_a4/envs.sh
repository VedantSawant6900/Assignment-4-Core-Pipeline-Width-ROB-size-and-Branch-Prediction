
export CSE530_A4_GEM5_PATH=/home/other/CSE530-FA2022/gem5/

export GEM5_BUILD_DIR=/home/other/CSE530-FA2022/gem5/build_a4/build/X86/gem5.opt

export CSE530_A4_TOP_DIR=/home/<user-name>/cse530_a4

export CSE530_A4_RESULT_PATH=$CSE530_A4_TOP_DIR/result
